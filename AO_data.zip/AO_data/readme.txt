In each data file:
NbProducts = |N|
NbCustomers = |M|
Utilities = matrix M x N
Revenue = vector N elements
 
