In each data file:
NbRetailers = |M| (Number of classes) 
NbProducts = |N|
Preference = \nu_{ij}
Revenue = \pi_{ij}
RevenueMax = \overline{\pi}_{i}
Fraction = \gamma_i
Capacity = \kappa 
Multiplier = 1/\nu_{i0}
MaximumCap = sum_{j=1}^k nu_{i[j]} (The sum of k largest preferences for each class)
Rank = The rank of each product's preference in a class (high to low)
 
